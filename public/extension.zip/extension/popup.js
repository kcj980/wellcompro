document.getElementById('open-danawa').addEventListener('click', () => {
  window.open('https://shop.danawa.com/virtualestimate/?controller=estimateMain&methods=index&marketPlaceSeq=16&logger_kw=dnw_gnb_esti', '_blank');
}); 